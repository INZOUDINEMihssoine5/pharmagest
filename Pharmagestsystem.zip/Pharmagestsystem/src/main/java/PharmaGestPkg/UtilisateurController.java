package PharmaGestPkg;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;

public class UtilisateurController {

    @FXML private TextField prenomField, nomField, telephoneField, emailField, adresseField, identifiantField, motDePasseField, statusField;
    @FXML private DatePicker dateNaissancePicker;
    @FXML private CheckBox superAdminCheckBox;

    @FXML private TableView<Utilisateur> utilisateurTable;
    @FXML private TableColumn<Utilisateur, String> identifiantColumn, prenomColumn, nomColumn, emailColumn, telephoneColumn, statusColumn;
    @FXML private TableColumn<Utilisateur, LocalDate> dateNaissanceColumn;
    @FXML private TableColumn<Utilisateur, Boolean> superAdminColumn;

    @FXML private Button ajouterButton;

    private final ObservableList<Utilisateur> utilisateurs = FXCollections.observableArrayList();
    private Connection connection;

    private boolean enModeModification = false;
    private Utilisateur utilisateurAModifier = null;

    @FXML
    public void initialize() {
        connection = DatabaseConnection.getConnection();
        if (connection == null) {
            afficherAlerteErreur("Erreur", "La connexion à la base de données a échoué.");
            return;
        }

        identifiantColumn.setCellValueFactory(new PropertyValueFactory<>("identifiant"));
        prenomColumn.setCellValueFactory(new PropertyValueFactory<>("prenom"));
        nomColumn.setCellValueFactory(new PropertyValueFactory<>("nom"));
        dateNaissanceColumn.setCellValueFactory(new PropertyValueFactory<>("dateNaissance"));
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        telephoneColumn.setCellValueFactory(new PropertyValueFactory<>("telephone"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        superAdminColumn.setCellValueFactory(new PropertyValueFactory<>("estSuperAdmin"));

        utilisateurTable.setItems(utilisateurs);
        chargerUtilisateurs();
    }

    private void chargerUtilisateurs() {
        utilisateurs.clear();
        String query = "SELECT * FROM \"utilisateur\"";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                utilisateurs.add(new Utilisateur(
                        rs.getString("identifiant"),
                        rs.getString("prenom"),
                        rs.getString("nom"),
                        rs.getDate("date_naissance") != null ? rs.getDate("date_naissance").toLocalDate() : null,
                        rs.getString("telephone"),
                        rs.getString("email"),
                        rs.getString("adresse"),
                        rs.getString("mot_de_passe"),
                        rs.getString("status"),
                        rs.getBoolean("est_superadmin")
                ));
            }

        } catch (SQLException e) {
            afficherAlerteErreur("Erreur", "Impossible de charger les utilisateurs.");
            e.printStackTrace();
        }
    }

    @FXML
    private void ajouterUtilisateur(ActionEvent event) {
        if (!champEstValide()) {
            afficherAlerteErreur("Champs invalides", "Veuillez remplir tous les champs requis.");
            return;
        }

        if (enModeModification && utilisateurAModifier != null) {
            String query = "UPDATE \"utilisateur\" SET prenom=?, nom=?, date_naissance=?, telephone=?, email=?, adresse=?, mot_de_passe=?, status=?, est_superadmin=? WHERE identifiant=?";
            try (PreparedStatement stmt = connection.prepareStatement(query)) {
                remplirStatementUtilisateurSansIdentifiant(stmt);
                stmt.setString(10, utilisateurAModifier.getIdentifiant());
                stmt.executeUpdate();
                chargerUtilisateurs();
                resetForm(null);
            } catch (SQLException e) {
                afficherAlerteErreur("Erreur", "Impossible de modifier l'utilisateur.");
                e.printStackTrace();
            }
        } else {
            String query = "INSERT INTO \"utilisateur\" (identifiant, prenom, nom, date_naissance, telephone, email, adresse, mot_de_passe, status, est_superadmin) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = connection.prepareStatement(query)) {
                remplirStatementUtilisateurComplet(stmt);
                stmt.executeUpdate();
                chargerUtilisateurs();
                resetForm(null);
            } catch (SQLException e) {
                afficherAlerteErreur("Erreur", "Impossible d'ajouter l'utilisateur.");
                e.printStackTrace();
            }
        }
    }

    @FXML
    private void modifierUtilisateur(ActionEvent event) {
        Utilisateur selected = utilisateurTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            afficherAlerteErreur("Avertissement", "Veuillez sélectionner un utilisateur.");
            return;
        }

        utilisateurAModifier = selected;
        enModeModification = true;

        identifiantField.setText(selected.getIdentifiant());
        prenomField.setText(selected.getPrenom());
        nomField.setText(selected.getNom());
        dateNaissancePicker.setValue(selected.getDateNaissance());
        telephoneField.setText(selected.getTelephone());
        emailField.setText(selected.getEmail());
        adresseField.setText(selected.getAdresse());
        motDePasseField.setText(selected.getMotDePasse());
        statusField.setText(selected.getStatus());
        superAdminCheckBox.setSelected(selected.isEstSuperAdmin());

        identifiantField.setDisable(true);
        ajouterButton.setText("Valider Modification");
    }

    @FXML
    private void supprimerUtilisateur(ActionEvent event) {
        Utilisateur selected = utilisateurTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            afficherAlerteErreur("Avertissement", "Veuillez sélectionner un utilisateur.");
            return;
        }

        String query = "DELETE FROM \"utilisateur\" WHERE identifiant=?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, selected.getIdentifiant());
            stmt.executeUpdate();
            utilisateurs.remove(selected);
            utilisateurTable.refresh();
            resetForm(null);
        } catch (SQLException e) {
            afficherAlerteErreur("Erreur", "Impossible de supprimer l'utilisateur.");
            e.printStackTrace();
        }
    }

    private boolean champEstValide() {
        return !identifiantField.getText().isEmpty() &&
                !prenomField.getText().isEmpty() &&
                !nomField.getText().isEmpty() &&
                dateNaissancePicker.getValue() != null &&
                !telephoneField.getText().isEmpty() &&
                !emailField.getText().isEmpty() &&
                !adresseField.getText().isEmpty() &&
                !motDePasseField.getText().isEmpty() &&
                !statusField.getText().isEmpty();
    }

    // Utilisé pour INSERT
    private void remplirStatementUtilisateurComplet(PreparedStatement stmt) throws SQLException {
        stmt.setString(1, identifiantField.getText());
        stmt.setString(2, prenomField.getText());
        stmt.setString(3, nomField.getText());
        stmt.setDate(4, Date.valueOf(dateNaissancePicker.getValue()));
        stmt.setString(5, telephoneField.getText());
        stmt.setString(6, emailField.getText());
        stmt.setString(7, adresseField.getText());
        stmt.setString(8, motDePasseField.getText());
        stmt.setString(9, statusField.getText());
        stmt.setBoolean(10, superAdminCheckBox.isSelected());
    }

    // Utilisé pour UPDATE (sans identifiant au début)
    private void remplirStatementUtilisateurSansIdentifiant(PreparedStatement stmt) throws SQLException {
        stmt.setString(1, prenomField.getText());
        stmt.setString(2, nomField.getText());
        stmt.setDate(3, Date.valueOf(dateNaissancePicker.getValue()));
        stmt.setString(4, telephoneField.getText());
        stmt.setString(5, emailField.getText());
        stmt.setString(6, adresseField.getText());
        stmt.setString(7, motDePasseField.getText());
        stmt.setString(8, statusField.getText());
        stmt.setBoolean(9, superAdminCheckBox.isSelected());
    }

    private void afficherAlerteErreur(String titre, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(titre);
        alert.setHeaderText("Une erreur est survenue");
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    private void resetForm(ActionEvent event) {
        prenomField.clear();
        nomField.clear();
        dateNaissancePicker.setValue(null);
        telephoneField.clear();
        emailField.clear();
        adresseField.clear();
        identifiantField.clear();
        motDePasseField.clear();
        statusField.clear();
        superAdminCheckBox.setSelected(false);
        identifiantField.setDisable(false);
        enModeModification = false;
        utilisateurAModifier = null;
        ajouterButton.setText("Ajouter");
    }

    @FXML
    private void retourOnAction(ActionEvent event) {
        try {
            Parent dashboardView = FXMLLoader.load(getClass().getResource("/PharmaGestPkg/Maintenance.fxml"));
            Scene dashboardScene = new Scene(dashboardView);
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            stage.setScene(dashboardScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
