package PharmaGestPkg;

import PharmaGestPkg.LoginApplication;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

import java.io.IOException;

public class DashboardController {

    @FXML
    private Label loginMessageLabel;
    private Stage stage;
    @FXML
    private Button maintenanceButton;

    // Method for "Changer d'utilisateur" button
    @FXML
    public void changeloginButtonOnAction(ActionEvent e) throws IOException {
        // Chargement de la scène du formulaire de changement de login
        FXMLLoader fxmlLoader = new FXMLLoader(LoginApplication.class.getResource("login.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setTitle("Login");
        stage.setScene(scene);
        stage.show();
    }

    // Method for "Quitter" button
    @FXML
    private void quitButtonOnAction(ActionEvent event) {
        // Logic for quitting the application
        // This can be done by closing the current window
        System.exit(0);
    }

    // Method for "Maintenance" button
    @FXML
    public void MaintenanceOnAction(ActionEvent event) {
        try {
            // Chargement de la scène de maintenance
            FXMLLoader fxmlLoader = new FXMLLoader(LoginApplication.class.getResource("/PharmaGestPkg/Maintenance.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 600, 400);
            // Récupération de la fenêtre actuelle et mise à jour de la scène
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setTitle("Maintenance");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            // Gestion de l'erreur en cas d'échec du chargement de la ressource FXML
            showErrorAlert("Erreur de chargement", "Impossible de charger la page de maintenance.");
            e.printStackTrace();
        }
    }

    // Méthode auxiliaire pour afficher une alerte en cas d'erreur
    private void showErrorAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public void VenteOnAction(ActionEvent event) {
        try {
            // Chargement de la scène de maintenance
            FXMLLoader fxmlLoader = new FXMLLoader(LoginApplication.class.getResource("/PharmaGestPkg/vente.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 600, 400);
            // Récupération de la fenêtre actuelle et mise à jour de la scène
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setTitle("Vente");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            // Gestion de l'erreur en cas d'échec du chargement de la ressource FXML
            showErrorAlert("Erreur de chargement", "Impossible de charger la page de vente.");
            e.printStackTrace();
        }
    }
}


