package PharmaGestPkg;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnection {

    public static Connection getConnection() {
        String databaseName = "PharmaGest";
        String databaseUser = "postgres";
        String databasePassword = "jrpictures97640";
        String url = "jdbc:postgresql://localhost:5432/" + databaseName;

        Connection databaselink = null;

        try {
            Class.forName("org.postgresql.Driver");
            databaselink = DriverManager.getConnection(url, databaseUser, databasePassword);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return databaselink;
    }
}
