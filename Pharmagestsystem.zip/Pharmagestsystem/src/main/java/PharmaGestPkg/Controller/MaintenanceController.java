package PharmaGestPkg.Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Node;

import java.io.IOException;

public class MaintenanceController {

    @FXML private Button medicamentButton;
    @FXML private Button retourdashboardButton;

    @FXML
    private void medicamentOnAction(ActionEvent event) {
        try {
            Parent medicamentView = FXMLLoader.load(getClass().getResource("/PharmaGestPkg/MedicamentView.fxml"));
            Scene medicamentScene = new Scene(medicamentView);
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            stage.setScene(medicamentScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void retourdashboardOnAction(ActionEvent event) {
        try {
            Parent dashboardView = FXMLLoader.load(getClass().getResource("/PharmaGestPkg/Dashboard.fxml"));
            Scene dashboardScene = new Scene(dashboardView);
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            stage.setScene(dashboardScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

        @FXML
        private void utilisateurOnAction(ActionEvent event) {
            try {
                Parent dashboardView = FXMLLoader.load(getClass().getResource("/PharmaGestPkg/Utilisateur.fxml"));
                Scene dashboardScene = new Scene(dashboardView);
                Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                stage.setScene(dashboardScene);
                stage.show();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
}
