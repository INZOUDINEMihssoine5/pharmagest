package PharmaGestPkg.Controller;

import PharmaGestPkg.DatabaseConnection;
import PharmaGestPkg.LoginApplication;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class LoginController {

    private Stage stage;

    @FXML
    private Button cancelButton;
    @FXML
    private Label loginMessageLabel;
    @FXML
    private Button loginButton;
    @FXML
    private TextField usernameTextfield;
    @FXML
    private PasswordField passwordPasswordfield;


    /**
     * Gestion de l'action du bouton de connexion
     */
    @FXML
    public void loginButtonOnAction(ActionEvent e) throws IOException {
        // Vérifie si les champs d'identifiant et de mot de passe ne sont pas vides
        if (!usernameTextfield.getText().isBlank() && !passwordPasswordfield.getText().isBlank()) {
            // Appel de la méthode de validation du login avec le paramètre ActionEvent
            validateLogin(e);
        } else {
            loginMessageLabel.setText("Veuillez entrer un identifiant et un mot de passe !");
        }
    }

    /**
     * Gestion de l'action du bouton d'annulation
     */
    @FXML
    public void cancelButtonOnAction(ActionEvent event) {
        // Ferme la fenêtre actuelle
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }

    /**
     * Méthode de validation du login
     */
    public void validateLogin(ActionEvent e) {
        // Connexion à la base de données
        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();

        // Requête SQL pour vérifier l'identifiant et le mot de passe
        String verifyLogin = "SELECT Count(0) FROM public.\"utilisateur\" WHERE \"identifiant\"='" +
                usernameTextfield.getText() + "' AND \"mot_de_passe\"='" +
                passwordPasswordfield.getText() + "';";

        try {
            // Exécution de la requête SQL
            Statement statement = connectDB.createStatement();
            ResultSet queryResult = statement.executeQuery(verifyLogin);

            // Vérification du résultat de la requête
            while (queryResult.next()) {
                if (queryResult.getInt(1) == 1) {
                    // Chargement de la scène du Dashboard
                    FXMLLoader fxmlLoader = new FXMLLoader(LoginApplication.class.getResource("Dashboard.fxml"));
                    Scene scene = new Scene(fxmlLoader.load(), 900, 600);
                    // Récupération de la fenêtre actuelle et changement de la scène
                    stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
                    stage.setTitle("Dashboard");
                    stage.setScene(scene);
                    stage.show();
                } else {
                    loginMessageLabel.setText("Login invalide. Veuillez réessayer.");
                }
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Gestion de l'action pour changer l'écran de connexion
     */
    @FXML
    public void changeloginButtonOnAction(ActionEvent e) throws IOException {
        // Chargement de la scène du formulaire de changement de login
        FXMLLoader fxmlLoader = new FXMLLoader(LoginApplication.class.getResource("login.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setTitle("Login");
        stage.setScene(scene);
        stage.show();
    }


}