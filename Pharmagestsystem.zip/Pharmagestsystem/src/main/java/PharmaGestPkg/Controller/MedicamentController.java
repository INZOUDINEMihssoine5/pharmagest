package PharmaGestPkg.Controller;

import PharmaGestPkg.Medicament;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.input.MouseEvent;

public class MedicamentController {

    @FXML private TextField nomField, prixVenteField, stockField, qteMaxField, prixAchatField, seuilCommandeField, familleField;
    @FXML private ComboBox<String> formeCombo, familleCombo, fournisseurCombo;
    @FXML private TableView<Medicament> tableMedicament;
    @FXML private TableColumn<Medicament, Integer> colId;
    @FXML private TableColumn<Medicament, String> colNom, colForme, colFamille, colFournisseur;
    @FXML private TableColumn<Medicament, Double> colPrixAchat, colPrixVente;
    @FXML private TableColumn<Medicament, Integer> colSeuil, colQteMax, colStock;
    @FXML private Button ajouterBtn, modifierBtn, supprimerBtn, retourMedicament;

    private ObservableList<Medicament> medicamentList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // Exemple d'initialisation des ComboBox
        formeCombo.setItems(FXCollections.observableArrayList("Comprimé", "Sirop", "Injection"));
        familleCombo.setItems(FXCollections.observableArrayList("Antibiotique", "Antalgique"));
        fournisseurCombo.setItems(FXCollections.observableArrayList("PharmaPlus", "DistribSanté"));

        // Initialisation des colonnes
        colId.setCellValueFactory(cell -> cell.getValue().idProperty().asObject());
        colNom.setCellValueFactory(cell -> cell.getValue().nomProperty());
        colForme.setCellValueFactory(cell -> cell.getValue().formeProperty());
        colPrixAchat.setCellValueFactory(cell -> cell.getValue().prixAchatProperty().asObject());
        colPrixVente.setCellValueFactory(cell -> cell.getValue().prixVenteProperty().asObject());
        colSeuil.setCellValueFactory(cell -> cell.getValue().seuilCommandeProperty().asObject());
        colQteMax.setCellValueFactory(cell -> cell.getValue().qteMaxProperty().asObject());
        colFamille.setCellValueFactory(cell -> cell.getValue().familleProperty());
        colFournisseur.setCellValueFactory(cell -> cell.getValue().fournisseurProperty());
        colStock.setCellValueFactory(cell -> cell.getValue().stockProperty().asObject());

        // Lier la liste à la table
        tableMedicament.setItems(medicamentList);

        // Gestion sélection table
        tableMedicament.setOnMouseClicked(this::onTableClick);
    }

    @FXML
    private void ajouterMedicament(ActionEvent event) {
        Medicament med = new Medicament(
                nomField.getText(),
                formeCombo.getValue(),
                Double.parseDouble(prixAchatField.getText()),
                Double.parseDouble(prixVenteField.getText()),
                Integer.parseInt(seuilCommandeField.getText()),
                Integer.parseInt(qteMaxField.getText()),
                familleCombo.getValue(),
                fournisseurCombo.getValue(),
                Integer.parseInt(stockField.getText())
        );
        medicamentList.add(med);
        clearFields();
    }

    @FXML
    private void modifierMedicament(ActionEvent event) {
        Medicament selected = tableMedicament.getSelectionModel().getSelectedItem();
        if (selected != null) {
            selected.setNom(nomField.getText());
            selected.setForme(formeCombo.getValue());
            selected.setPrixAchat(Double.parseDouble(prixAchatField.getText()));
            selected.setPrixVente(Double.parseDouble(prixVenteField.getText()));
            selected.setSeuilCommande(Integer.parseInt(seuilCommandeField.getText()));
            selected.setQteMax(Integer.parseInt(qteMaxField.getText()));
            selected.setFamille(familleCombo.getValue());
            selected.setFournisseur(fournisseurCombo.getValue());
            selected.setStock(Integer.parseInt(stockField.getText()));
            tableMedicament.refresh();
            clearFields();
        }
    }

    @FXML
    private void supprimerMedicament(ActionEvent event) {
        Medicament selected = tableMedicament.getSelectionModel().getSelectedItem();
        if (selected != null) {
            medicamentList.remove(selected);
        }
    }

    @FXML
    private void retourMedicamentOnAction(ActionEvent event) {
        // Ajoute ici le code pour revenir à la vue précédente (ex: navigation)
        System.out.println("Retour au menu précédent");
    }

    private void onTableClick(MouseEvent event) {
        Medicament selected = tableMedicament.getSelectionModel().getSelectedItem();
        if (selected != null) {
            nomField.setText(selected.getNom());
            formeCombo.setValue(selected.getForme());
            prixAchatField.setText(String.valueOf(selected.getPrixAchat()));
            prixVenteField.setText(String.valueOf(selected.getPrixVente()));
            seuilCommandeField.setText(String.valueOf(selected.getSeuilCommande()));
            qteMaxField.setText(String.valueOf(selected.getQteMax()));
            familleCombo.setValue(selected.getFamille());
            fournisseurCombo.setValue(selected.getFournisseur());
            stockField.setText(String.valueOf(selected.getStock()));
        }
    }

    private void clearFields() {
        nomField.clear();
        formeCombo.setValue(null);
        prixAchatField.clear();
        prixVenteField.clear();
        seuilCommandeField.clear();
        qteMaxField.clear();
        familleCombo.setValue(null);
        fournisseurCombo.setValue(null);
        stockField.clear();
    }
}
