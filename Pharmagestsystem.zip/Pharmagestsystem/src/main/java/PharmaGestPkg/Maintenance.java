package PharmaGestPkg;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Maintenance {

    public void showWindow() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/PharmaGestPkg/Maintenance.fxml"));
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setTitle("Maintenance - PharmaGest");
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
