package PharmaGestPkg;

public class LigneCmdLivraison {
    private int qteCmd;
    private int qteLivree;
    private double PUCommandee;
    private CommandeLivraison commandeLivraison;
    private Medicament medicament;

    public LigneCmdLivraison(int qteCmd, int qteLivree, double PUCommandee, CommandeLivraison commandeLivraison, Medicament medicament) {
        this.qteCmd = qteCmd;
        this.qteLivree = qteLivree;
        this.PUCommandee = PUCommandee;
        this.commandeLivraison = commandeLivraison;
        this.medicament = medicament;
    }

    // Getters et Setters
    public int getQteCmd() { return qteCmd; }
    public void setQteCmd(int qteCmd) { this.qteCmd = qteCmd; }

    public int getQteLivree() { return qteLivree; }
    public void setQteLivree(int qteLivree) { this.qteLivree = qteLivree; }

    public double getPUCommandee() { return PUCommandee; }
    public void setPUCommandee(double PUCommandee) { this.PUCommandee = PUCommandee; }

    public CommandeLivraison getCommandeLivraison() { return commandeLivraison; }
    public void setCommandeLivraison(CommandeLivraison commandeLivraison) { this.commandeLivraison = commandeLivraison; }

    public Medicament getMedicament() { return medicament; }
    public void setMedicament(Medicament medicament) { this.medicament = medicament; }
}
