package PharmaGestPkg;

import java.util.Date;

public class CommandeLivraison {
    private int numCommande;
    private Date dateCommande;
    private Date dateLivraison;
    private String noBondeLivraisonFrn;

    public CommandeLivraison(int numCommande, Date dateCommande, Date dateLivraison, String noBondeLivraisonFrn) {
        this.numCommande = numCommande;
        this.dateCommande = dateCommande;
        this.dateLivraison = dateLivraison;
        this.noBondeLivraisonFrn = noBondeLivraisonFrn;
    }

    // Getters et Setters
    public int getNumCommande() { return numCommande; }
    public void setNumCommande(int numCommande) { this.numCommande = numCommande; }

    public Date getDateCommande() { return dateCommande; }
    public void setDateCommande(Date dateCommande) { this.dateCommande = dateCommande; }

    public Date getDateLivraison() { return dateLivraison; }
    public void setDateLivraison(Date dateLivraison) { this.dateLivraison = dateLivraison; }

    public String getNoBondeLivraisonFrn() { return noBondeLivraisonFrn; }
    public void setNoBondeLivraisonFrn(String noBondeLivraisonFrn) { this.noBondeLivraisonFrn = noBondeLivraisonFrn; }
}
