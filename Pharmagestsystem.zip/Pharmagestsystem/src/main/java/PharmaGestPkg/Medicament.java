package PharmaGestPkg;

import javafx.beans.property.*;

public class Medicament {

    private static int idCounter = 1; // Simple auto-incrémentation pour l'exemple

    private final IntegerProperty id;
    private final StringProperty nom;
    private final StringProperty forme;
    private final DoubleProperty prixAchat;
    private final DoubleProperty prixVente;
    private final IntegerProperty seuilCommande;
    private final IntegerProperty qteMax;
    private final StringProperty famille;
    private final StringProperty fournisseur;
    private final IntegerProperty stock;

    public Medicament(String nom, String forme, double prixAchat, double prixVente,
                      int seuilCommande, int qteMax, String famille, String fournisseur, int stock) {
        this.id = new SimpleIntegerProperty(idCounter++);
        this.nom = new SimpleStringProperty(nom);
        this.forme = new SimpleStringProperty(forme);
        this.prixAchat = new SimpleDoubleProperty(prixAchat);
        this.prixVente = new SimpleDoubleProperty(prixVente);
        this.seuilCommande = new SimpleIntegerProperty(seuilCommande);
        this.qteMax = new SimpleIntegerProperty(qteMax);
        this.famille = new SimpleStringProperty(famille);
        this.fournisseur = new SimpleStringProperty(fournisseur);
        this.stock = new SimpleIntegerProperty(stock);
    }

    // Getters et setters avec propriétés JavaFX
    public int getId() { return id.get(); }
    public IntegerProperty idProperty() { return id; }

    public String getNom() { return nom.get(); }
    public void setNom(String value) { nom.set(value); }
    public StringProperty nomProperty() { return nom; }

    public String getForme() { return forme.get(); }
    public void setForme(String value) { forme.set(value); }
    public StringProperty formeProperty() { return forme; }

    public double getPrixAchat() { return prixAchat.get(); }
    public void setPrixAchat(double value) { prixAchat.set(value); }
    public DoubleProperty prixAchatProperty() { return prixAchat; }

    public double getPrixVente() { return prixVente.get(); }
    public void setPrixVente(double value) { prixVente.set(value); }
    public DoubleProperty prixVenteProperty() { return prixVente; }

    public int getSeuilCommande() { return seuilCommande.get(); }
    public void setSeuilCommande(int value) { seuilCommande.set(value); }
    public IntegerProperty seuilCommandeProperty() { return seuilCommande; }

    public int getQteMax() { return qteMax.get(); }
    public void setQteMax(int value) { qteMax.set(value); }
    public IntegerProperty qteMaxProperty() { return qteMax; }

    public String getFamille() { return famille.get(); }
    public void setFamille(String value) { famille.set(value); }
    public StringProperty familleProperty() { return famille; }

    public String getFournisseur() { return fournisseur.get(); }
    public void setFournisseur(String value) { fournisseur.set(value); }
    public StringProperty fournisseurProperty() { return fournisseur; }

    public int getStock() { return stock.get(); }
    public void setStock(int value) { stock.set(value); }
    public IntegerProperty stockProperty() { return stock; }
}
