package PharmaGestPkg;

import javafx.beans.property.*;
import java.time.LocalDate;

public class Utilisateur {

    private final StringProperty identifiant;
    private final StringProperty prenom;
    private final StringProperty nom;
    private final ObjectProperty<LocalDate> dateNaissance;
    private final StringProperty telephone;
    private final StringProperty email;
    private final StringProperty adresse;
    private final StringProperty motDePasse;
    private final StringProperty status;
    private final BooleanProperty estSuperAdmin;

    public Utilisateur(String identifiant, String prenom, String nom, LocalDate dateNaissance,
                       String telephone, String email, String adresse, String motDePasse,
                       String status, boolean estSuperAdmin) {
        this.identifiant = new SimpleStringProperty(identifiant);
        this.prenom = new SimpleStringProperty(prenom);
        this.nom = new SimpleStringProperty(nom);
        this.dateNaissance = new SimpleObjectProperty<>(dateNaissance);
        this.telephone = new SimpleStringProperty(telephone);
        this.email = new SimpleStringProperty(email);
        this.adresse = new SimpleStringProperty(adresse);
        this.motDePasse = new SimpleStringProperty(motDePasse);
        this.status = new SimpleStringProperty(status);
        this.estSuperAdmin = new SimpleBooleanProperty(estSuperAdmin);
    }

    // Getters pour JavaFX (propriétés observables)
    public StringProperty identifiantProperty() { return identifiant; }
    public StringProperty prenomProperty() { return prenom; }
    public StringProperty nomProperty() { return nom; }
    public ObjectProperty<LocalDate> dateNaissanceProperty() { return dateNaissance; }
    public StringProperty telephoneProperty() { return telephone; }
    public StringProperty emailProperty() { return email; }
    public StringProperty adresseProperty() { return adresse; }
    public StringProperty motDePasseProperty() { return motDePasse; }
    public StringProperty statusProperty() { return status; }
    public BooleanProperty estSuperAdminProperty() { return estSuperAdmin; }

    // Getters classiques
    public String getIdentifiant() { return identifiant.get(); }
    public String getPrenom() { return prenom.get(); }
    public String getNom() { return nom.get(); }
    public LocalDate getDateNaissance() { return dateNaissance.get(); }
    public String getTelephone() { return telephone.get(); }
    public String getEmail() { return email.get(); }
    public String getAdresse() { return adresse.get(); }
    public String getMotDePasse() { return motDePasse.get(); }
    public String getStatus() { return status.get(); }
    public boolean isEstSuperAdmin() { return estSuperAdmin.get(); }

    // Setters
    public void setIdentifiant(String identifiant) { this.identifiant.set(identifiant); }
    public void setPrenom(String prenom) { this.prenom.set(prenom); }
    public void setNom(String nom) { this.nom.set(nom); }
    public void setDateNaissance(LocalDate dateNaissance) { this.dateNaissance.set(dateNaissance); }
    public void setTelephone(String telephone) { this.telephone.set(telephone); }
    public void setEmail(String email) { this.email.set(email); }
    public void setAdresse(String adresse) { this.adresse.set(adresse); }
    public void setMotDePasse(String motDePasse) { this.motDePasse.set(motDePasse); }
    public void setStatus(String status) { this.status.set(status); }
    public void setEstSuperAdmin(boolean estSuperAdmin) { this.estSuperAdmin.set(estSuperAdmin); }

    // Méthode toString pour afficher les informations de l'utilisateur
    @Override
    public String toString() {
        return "Utilisateur{" +
                "identifiant='" + identifiant.get() + '\'' +
                ", prenom='" + prenom.get() + '\'' +
                ", nom='" + nom.get() + '\'' +
                ", dateNaissance=" + dateNaissance.get() +
                ", telephone='" + telephone.get() + '\'' +
                ", email='" + email.get() + '\'' +
                ", adresse='" + adresse.get() + '\'' +
                ", motDePasse='" + motDePasse.get() + '\'' +
                ", status='" + status.get() + '\'' +
                ", estSuperAdmin=" + estSuperAdmin.get() +
                '}';
    }
}
