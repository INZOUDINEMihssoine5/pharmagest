package PharmaGestPkg;

public class Forme {
    private String nomForme;

    public Forme(String nomForme) {
        this.nomForme = nomForme;
    }

    public static Forme values() {
        return null;
    }

    // Getters et Setters
    public String getNomForme() { return nomForme; }
    public void setNomForme(String nomForme) { this.nomForme = nomForme; }
}
