module com.example.login {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires org.postgresql.jdbc;

    opens PharmaGestPkg to javafx.fxml;
    exports PharmaGestPkg;
    exports PharmaGestPkg.Controller;
    opens PharmaGestPkg.Controller to javafx.fxml;
}